import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'app_colors.dart';
import 'quiz_screen.dart';

class HouseDetailScreen extends StatefulWidget {
  final String title;
  final String location;
  final String regionName;
  final String description;
  final String imageUrl;

  const HouseDetailScreen({
    super.key,
    required this.title,
    required this.location,
    required this.regionName,
    required this.description,
    required this.imageUrl,
  });

  @override
  State<HouseDetailScreen> createState() => _HouseDetailScreenState();
}

class _HouseDetailScreenState extends State<HouseDetailScreen> {
  bool isFavorite = false;
  final User? _user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _checkFavoriteStatus();
  }

  Future<void> _checkFavoriteStatus() async {
    if (_user == null) return;

    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(_user.uid)
          .collection('favorites')
          .doc(widget.title)
          .get();

      if (mounted) {
        setState(() {
          isFavorite = doc.exists;
        });
      }
    } catch (e) {
      debugPrint("Gagal memuat status favorit: $e");
    }
  }

  Future<void> _toggleFavorite() async {
    if (_user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Silakan login terlebih dahulu.')),
      );
      return;
    }

    final docRef = FirebaseFirestore.instance
        .collection('users')
        .doc(_user.uid)
        .collection('favorites')
        .doc(widget.title);

    // Optimistic UI update
    setState(() {
      isFavorite = !isFavorite;
    });

    try {
      if (isFavorite) {
        await docRef.set({
          'title': widget.title,
          'location': widget.location,
          'regionName': widget.regionName,
          'description': widget.description,
          'imageUrl': widget.imageUrl,
          'timestamp': FieldValue.serverTimestamp(),
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Ditambahkan ke favorit! ❤️',
                style: GoogleFonts.poppins(),
              ),
              duration: const Duration(seconds: 1),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          );
        }
      } else {
        await docRef.delete();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Dihapus dari favorit.',
                style: GoogleFonts.poppins(),
              ),
              duration: const Duration(seconds: 1),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          );
        }
      }
    } catch (e) {
      // Revert jika gagal
      if (mounted) {
        setState(() {
          isFavorite = !isFavorite;
        });
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Terjadi kesalahan: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ==========================================
              // 1. Bagian Atas (Header & Hero Image)
              // ==========================================
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Stack(
                  children: [
                    // Hero Image
                    Hero(
                      tag: widget
                          .title, // Animasi transisi cantik jika dihubungkan dari gambar awal
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.network(
                          widget.imageUrl,
                          width: double.infinity,
                          height: 320,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              Container(
                                height: 320,
                                color: Colors.grey.shade300,
                                child: const Icon(Icons.broken_image, size: 50),
                              ),
                        ),
                      ),
                    ),

                    // Tombol Kembali
                    Positioned(
                      top: 16,
                      left: 16,
                      child: _buildCircleButton(
                        icon: Icons.arrow_back_rounded,
                        onTap: () => Navigator.pop(context),
                      ),
                    ),

                    // Ikon Favorit/Bookmark
                    Positioned(
                      top: 16,
                      right: 16,
                      child: _buildCircleButton(
                        icon: isFavorite
                            ? Icons.favorite
                            : Icons.favorite_border_rounded,
                        iconColor: isFavorite
                            ? Colors.redAccent
                            : AppColors.secondaryText,
                        onTap: _toggleFavorite,
                      ),
                    ),
                  ],
                ),
              ),

              // ==========================================
              // 2. Bagian Identitas (Informasi Singkat)
              // ==========================================
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.title,
                      style: GoogleFonts.lora(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: AppColors.secondaryText,
                        height: 1.2,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Komponen Badge/Chip (Lokasi & Pulau)
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _buildChip(widget.location, Icons.location_on_rounded),
                        _buildChip(
                          'Pulau ${widget.regionName}',
                          Icons.explore_rounded,
                        ),
                      ],
                    ),

                    const SizedBox(height: 32),
                    const Divider(height: 1, thickness: 1),
                    const SizedBox(height: 24),

                    // ==========================================
                    // 3. Bagian Konten Utama (Scrollable Body)
                    // ==========================================
                    Text(
                      'Filosofi & Arsitektur',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.secondaryText,
                      ),
                    ),
                    const SizedBox(height: 12),

                    Text(
                      widget.description,
                      textAlign: TextAlign.justify,
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        height: 1.8, // Line spacing lega dan nyaman dibaca
                        color: AppColors.secondaryText.withValues(alpha: 0.85),
                      ),
                    ),

                    // Memberikan jarak yang aman agar teks terakhir tidak tertutup tombol bawah
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),

      // ==========================================
      // 4. Tombol Aksi (Uji Pemahaman)
      // ==========================================
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: SafeArea(
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => QuizScreen(region: widget.regionName),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              padding: const EdgeInsets.symmetric(vertical: 16),
              elevation: 4,
              shadowColor: AppColors.primary.withValues(alpha: 0.4),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.school_rounded, color: Colors.white, size: 20),
                const SizedBox(width: 10),
                Text(
                  'Uji Pemahaman (Kuis)',
                  style: GoogleFonts.poppins(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper untuk membuat tombol bulat melayang (Back & Heart)
  Widget _buildCircleButton({
    required IconData icon,
    required VoidCallback onTap,
    Color iconColor = AppColors.secondaryText,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.9),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Icon(icon, size: 22, color: iconColor),
      ),
    );
  }

  // Helper untuk membuat Badge/Chip estetik
  Widget _buildChip(String label, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.primary.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.primary.withValues(alpha: 0.15)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: AppColors.primary),
          const SizedBox(width: 6),
          Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: AppColors.primary,
            ),
          ),
        ],
      ),
    );
  }
}
