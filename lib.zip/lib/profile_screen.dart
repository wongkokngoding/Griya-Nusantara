import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';
import 'login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _showDeleteAccountDialog(BuildContext context, User? user) {
    showDialog(
      context: context,
      builder: (context) {
        bool isLoading = false;
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Hapus Akun'),
              content: const Text(
                'Apakah Anda yakin ingin menghapus akun ini? Tindakan ini tidak dapat dibatalkan.',
              ),
              actions: [
                TextButton(
                  onPressed: isLoading ? null : () => Navigator.pop(context),
                  child: const Text('Batal'),
                ),
                ElevatedButton(
                  onPressed: isLoading
                      ? null
                      : () async {
                          setState(() => isLoading = true);
                          try {
                            if (user != null) {
                              // Hapus data dari Firestore jika perlu
                              await FirebaseFirestore.instance
                                  .collection('users')
                                  .doc(user.uid)
                                  .delete();
                              // Hapus user dari Auth
                              await user.delete();
                            }
                            if (context.mounted) {
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const LoginScreen(),
                                ),
                                (route) => false,
                              );
                            }
                          } on FirebaseAuthException catch (e) {
                            setState(() => isLoading = false);
                            if (context.mounted) {
                              Navigator.pop(context); // Tutup dialog
                              String errorMsg =
                                  'Gagal menghapus akun: ${e.message}';
                              if (e.code == 'requires-recent-login') {
                                errorMsg =
                                    'Sesi telah kedaluwarsa. Silakan masuk kembali (keluar & masuk) lalu coba lagi.';
                              }
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(errorMsg),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          } catch (e) {
                            setState(() => isLoading = false);
                            if (context.mounted) {
                              Navigator.pop(context); // Tutup dialog
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Terjadi kesalahan: $e'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          }
                        },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text(
                          'Hapus',
                          style: TextStyle(color: Colors.white),
                        ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Center(child: Text('Akun belum masuk'));
    }

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final data = snapshot.data!.data() ?? <String, dynamic>{};
        final int xp = (data['xp'] ?? 0) as int;
        final int level = (data['level'] ?? 1) as int;
        final List<String> badges = List<String>.from(
          data['badges'] ?? <String>[],
        );
        final String levelTitle = _levelTitle(level);
        final int nextLevelXp = _xpForLevel(level + 1);
        final int currentLevelXp = _xpForLevel(level);
        final double progress = nextLevelXp > currentLevelXp
            ? ((xp - currentLevelXp) / (nextLevelXp - currentLevelXp)).clamp(
                0,
                1,
              )
            : 1.0;

        return ListView(
          padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
          children: [
            // Bagian Header Profil
            Center(
              child: Column(
                children: [
                  const CircleAvatar(
                    radius: 50,
                    backgroundColor: AppColors.border,
                    backgroundImage: NetworkImage(
                      'https://i.pravatar.cc/150?img=11',
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    user.email ?? 'Pengguna',
                    style: GoogleFonts.lora(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: AppColors.secondaryText,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    levelTitle,
                    style: GoogleFonts.manrope(
                      fontSize: 14,
                      color: AppColors.greyText,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.secondaryText.withValues(alpha: 0.05),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Gamifikasi',
                    style: GoogleFonts.lora(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppColors.secondaryText,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Level',
                              style: GoogleFonts.manrope(
                                fontSize: 12,
                                color: AppColors.greyText,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '$level',
                              style: GoogleFonts.lora(
                                fontSize: 32,
                                fontWeight: FontWeight.bold,
                                color: AppColors.secondaryText,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              'XP',
                              style: GoogleFonts.manrope(
                                fontSize: 12,
                                color: AppColors.greyText,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '$xp',
                              style: GoogleFonts.lora(
                                fontSize: 32,
                                fontWeight: FontWeight.bold,
                                color: AppColors.secondaryText,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  LinearProgressIndicator(
                    value: progress,
                    color: AppColors.primary,
                    backgroundColor: AppColors.border,
                    minHeight: 10,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Menuju level ${level + 1} • ${xp - currentLevelXp} / ${nextLevelXp - currentLevelXp} XP',
                    style: GoogleFonts.poppins(
                      fontSize: 13,
                      color: AppColors.greyText,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Badge Teratas',
                    style: GoogleFonts.manrope(
                      fontWeight: FontWeight.bold,
                      color: AppColors.secondaryText,
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (badges.isEmpty)
                    Text(
                      'Belum ada badge. Selesaikan kuis untuk dapat badge pertama!',
                      style: GoogleFonts.poppins(
                        fontSize: 13,
                        color: AppColors.greyText,
                      ),
                    )
                  else
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: badges.take(6).map((badge) {
                        return Chip(
                          backgroundColor: AppColors.primary.withValues(
                            alpha: 0.12,
                          ),
                          label: Text(
                            badge,
                            style: GoogleFonts.manrope(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: AppColors.primary,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            // Bagian Menu / List Options
            Container(
              padding: const EdgeInsets.symmetric(
                vertical: 8.0,
                horizontal: 8.0,
              ),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.secondaryText.withValues(alpha: 0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    leading: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.logout, color: AppColors.primary),
                    ),
                    title: Text(
                      'Keluar',
                      style: GoogleFonts.manrope(
                        fontWeight: FontWeight.bold,
                        color: AppColors.primary,
                      ),
                    ),
                    trailing: const Icon(
                      Icons.chevron_right,
                      color: AppColors.greyText,
                    ),
                    onTap: () async {
                      final nav = Navigator.of(context);
                      await FirebaseAuth.instance.signOut();
                      nav.pushAndRemoveUntil(
                        MaterialPageRoute(
                          builder: (context) => const LoginScreen(),
                        ),
                        (route) => false,
                      );
                    },
                  ),
                  const Divider(
                    color: AppColors.border,
                    height: 1,
                    indent: 16,
                    endIndent: 16,
                  ),
                  ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    leading: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.red.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.delete_forever,
                        color: Colors.red,
                      ),
                    ),
                    title: Text(
                      'Hapus Akun',
                      style: GoogleFonts.manrope(
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                    trailing: const Icon(
                      Icons.chevron_right,
                      color: AppColors.greyText,
                    ),
                    onTap: () => _showDeleteAccountDialog(context, user),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  int _xpForLevel(int level) {
    if (level <= 1) return 0;
    if (level == 2) return 200;
    if (level == 3) return 500;
    if (level == 4) return 900;
    if (level == 5) return 1500;
    return 2500;
  }

  String _levelTitle(int level) {
    switch (level) {
      case 1:
        return 'Penjelajah Budaya';
      case 2:
        return 'Pakar Daerah';
      case 3:
        return 'Nusantara Explorer';
      case 4:
        return 'Ahli Tradisi';
      case 5:
        return 'Guru Warisan';
      default:
        return 'Legenda Nusantara';
    }
  }
}
